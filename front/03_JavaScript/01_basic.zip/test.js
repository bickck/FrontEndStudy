

/* test.js */
alert("test.js 파일 입니다..");
document.write('외부 파일 로드..');
console.log('go~ go~');